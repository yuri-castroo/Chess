import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.Timer;
 
public class ChessGUI extends JFrame implements MouseListener, MouseMotionListener, ActionListener {

  // Define class variables
  private static final long serialVersionUID = 1L; // Used for what??? 
  JLayeredPane layeredPane;
  JPanel chessBoard;
  JLabel chessPiece;
  int xAdjust;
  int yAdjust;
  Container initParent; // Parent of initial chess piece to move
  private int init_x; // Initial x-value for piece (before moving with mouse)
  private int init_y; // Initial y-value for piece (before moving with mouse)
  private ArrayList<ChessPiece> pieceLocations;
  private ArrayList<ChessPiece> validMovesUser = null;
  private ArrayList<ChessPiece> validMovesComputer = null;
  
 
  
  // Timer GUI-specific variables 
  private JLabel timeLabel = new JLabel();
  private myTimer panel;
  private myTimer panel2;
  
  // Timer-specific variables
  private static final int ONE_SECOND = 1000;
  private int count = 6000000;
  private boolean isTimerActive = false;
  private Timer tmr = new Timer(ONE_SECOND, this);
 
  //Format time 
  private String formatTime(int count) {
      int hours = count / 3600;
      int minutes = (count-hours*3600)/60;
      int seconds = count-minutes*60;

      return String.format("%02d", hours) + " : " + String.format("%02d", minutes) + " : " + String.format("%02d", seconds);
  }
  
  // Constructor 
  public ChessGUI()
  {
	  Dimension boardSize = new Dimension(600, 700);
	  panel = new myTimer(true);
	  panel2 = new myTimer(false);
	  // Use Layered Pane for Chess GUI  
	  layeredPane = new JLayeredPane();
	  getContentPane().add(layeredPane);
	  layeredPane.setPreferredSize(boardSize);
	  layeredPane.addMouseListener(this);
	  layeredPane.addMouseMotionListener(this);

  	  timeLabel.setText(formatTime(count));
  	  timeLabel.setText("         ");

	  
	  // Timer GUI 
	  timeLabel = new JLabel();
	  timeLabel.setBorder(BorderFactory.createRaisedBevelBorder());
      layeredPane.add(panel.getPanel(), BorderLayout.SOUTH);
      panel.getPanel().setBounds(150, 10, 300, 150);
      layeredPane.add(panel2.getPanel(), BorderLayout.SOUTH);
      panel2.getPanel().setBounds(125, 650, 350, 150);
      //panel.setLayout(new BorderLayout());
      //panel.setBounds(0, 0, 5, 5);
      
      // Begin timer 
      count = 0; 
      isTimerActive = true;
      tmr.start();
	 
	  //Add a chess board to the Layered Pane 
	  chessBoard = new JPanel();
	  layeredPane.add(chessBoard, JLayeredPane.DEFAULT_LAYER);
	  chessBoard.setLayout( new GridLayout(8, 8) );
	  chessBoard.setPreferredSize( boardSize );
	  chessBoard.setBounds(0, 50, 600, 600);
	 
	  // Create initial board 
	  for (int i = 0; i < 64; i++) 
	  {
		  JPanel square = new JPanel( new BorderLayout()); // Create board square
		  chessBoard.add( square ); // Add square to board 
		  int row = (i / 8) % 2; // Get row 
		  if (row == 0) square.setBackground( i % 2 == 0 ? Color.LIGHT_GRAY : Color.DARK_GRAY );
		  else square.setBackground( i % 2 == 0 ? Color.DARK_GRAY  : Color.LIGHT_GRAY );
	  }
	  
	  //Add a few pieces to the board 
	  ArrayList<JLabel> pieceList = new ArrayList<>();
	  String s = System.getProperty("user.dir") + "\\src\\"; // Main file path 
	  /////////// INITIALIZE BASED ON THE USER DECISION ///////////
	  String s1 = s + "b"; // File path for all black strings
	  String s2 = s + "w"; // File path for all white strings
	  
	  // Put chess pieces in a list 
	  for(int i = 1; i <= 64; i++)
	  {
		  JLabel piece = new JLabel(); 
		  if(i <= 8) piece = new JLabel( new ImageIcon( s1 + i + ".png") ); // Valued black pieces
		  else if(i > 8 && i <= 16) piece = new JLabel( new ImageIcon( s1 + ".png") ); // Black pawns
		  else if(i >= 49 && i <= 56) piece = new JLabel( new ImageIcon( s2 + ".png") ); // White pawns
		  else if(i > 56 && i <= 64) piece = new JLabel( new ImageIcon( s2 + (65-i) + ".png") ); // Valued white pieces
		  pieceList.add(piece);
	  }
	  
	  // Create list of panels
	  ArrayList<JPanel> jpanelList = new ArrayList<>(); 
	  for(int i = 0; i < 64; i++)
	  {
		  JPanel myPanel = (JPanel)chessBoard.getComponent(i);
		  jpanelList.add(myPanel); 
	  }
	  
	  // Add chess piece to panels
	  for(int i = 0; i < pieceList.size(); i++)
	  {
		  jpanelList.get(i).add(pieceList.get(i));
	  }
	  
	  // Initializing the pieceLocation data to edit.
		// Create a standard set of pieceLocations.
		pieceLocations = new ArrayList<ChessPiece>();
		for (int i = 0; i < 8; i++)
		{
			ChessPiece p1 = null; 
			// Computer's Pieces
			for (int j = 0; j < 2; j++)
			{
				// Delineating between the back line and the front line.
				if (j == 0)
				{
					if ((i == 0) || (i == 7))
					{
						p1 = new ChessPiece(i * 75, 75 * j + 50, "rook", false);						
					}
					if ((i == 1) || (i == 6))
					{
						p1 = new ChessPiece(i * 75, 75 * j + 50, "knight", false);						
					}
					if ((i == 2) || (i == 5))
					{
						p1 = new ChessPiece(i * 75, 75 * j + 50, "bishop", false);						
					}
					if (i == 4)
					{
						p1 = new ChessPiece(i * 75, 75 * j + 50, "king", false);						
					}
					if (i == 3)
					{
						p1 = new ChessPiece(i * 75, 75 * j + 50, "queen", false);
					}
				}
				else
				{
					p1 = new ChessPiece(i * 75, 75 * j + 50, "cp" + i, false);
				}
				pieceLocations.add(p1);
			}
			// User's Pieces
			for (int j = 0; j < 2; j++)
			{
				// Delineating between the back line and the front line.
				if (j == 1)
				{
					if ((i == 0) || (i == 7))
					{
						p1 = new ChessPiece(i * 75, 75 * j + 500, "rook", true);						
					}
					if ((i == 1) || (i == 6))
					{
						p1 = new ChessPiece(i * 75, 75 * j + 500, "knight", true);						
					}
					if ((i == 2) || (i == 5))
					{
						p1 = new ChessPiece(i * 75, 75 * j + 500, "bishop", true);						
					}
					if (i == 4)
					{
						p1 = new ChessPiece(i * 75, 75 * j + 500, "queen", true);						
					}
					if (i == 3)
					{
						p1 = new ChessPiece(i * 75, 75 * j + 500, "king", true);
					}
				}
				else
				{
					p1 = new ChessPiece(i * 75, 75 * j + 500, "pawn" + i, true);
				}
				pieceLocations.add(p1);
			}
		}
  }
  
  // If user presses mouse
  public void mousePressed(MouseEvent e)
  {
	  chessPiece = null; // Initialize chess piece
	  Component c =  chessBoard.findComponentAt(e.getX(), e.getY() - 50); // Get piece coordinates
	  initParent = c.getParent(); // Set initial parent! (Put chess piece back here if invalid position specified) 
	  
	  if (c instanceof JPanel) return; // If user clicks on board (not chess piece) 
	 
	  // Determine coordinates of new point 
	  Point parentLocation = c.getParent().getLocation(); 
	  xAdjust = parentLocation.x - e.getX();
	  yAdjust = parentLocation.y - e.getY() + 50;
	  chessPiece = (JLabel)c;
	  
	  init_x = e.getX() + xAdjust;
	  init_y = e.getY() + yAdjust;
	  
	  chessPiece.setLocation(e.getX() + xAdjust, e.getY() + yAdjust); // Set new location 
	  chessPiece.setSize(chessPiece.getWidth(), chessPiece.getHeight()); // Set size of chess piece
	  layeredPane.add(chessPiece, JLayeredPane.DRAG_LAYER); // Add piece to layered pane
  }
 
  // Move chess piece around board
  public void mouseDragged(MouseEvent me) 
  {
	  if (chessPiece == null) return; // If chess piece is not defined, return
	  chessPiece.setLocation(me.getX() + xAdjust, me.getY() + yAdjust); // Else set location
  }
 
  // Put chess piece back onto chess board
  public void mouseReleased(MouseEvent e) 
  {
	  if(chessPiece == null) return; // If chess piece is not defined, return
	  
	  chessPiece.setVisible(false); // Hide chess piece momentarily
	  Component c =  chessBoard.findComponentAt(e.getX(), e.getY() - 50); // Find chess piece
	  
	  // Is there another piece here enemy or friend.
	  Container parent = null;
	  if (c instanceof JLabel) // If mouse clicks on pre-existing chess piece
	  { 
		  parent = c.getParent();
		  System.out.println("parentX: " + parent.getX());
		  System.out.println("parentY: " + parent.getY());
		  parent.remove(0); // Remove previous chess piece! - Might need to edit later!
		  parent.add( chessPiece ); // Add new piece 
	  }
	  else // If mouse clicks on board space (empty square)
	  {
		  parent = (Container) c;
		  if(e.getX() >= 0 && e.getX() <= 600 && e.getY() >= 50 && e.getY() <= 650) // Check bounds! 
		  {
			  parent.add( chessPiece );
		  }
		  else initParent.add(chessPiece); // Else put chess piece back in original spot 
	  }
	  chessPiece.setVisible(true); // Display chess piece 
	  // Add to pieceLocations.
	  for(int i = 0; i < pieceLocations.size(); i++)
	  {
		  if(pieceLocations.get(i).getX() == init_x && pieceLocations.get(i).getY() == init_y)
		  {
			  pieceLocations.get(i).setX(parent.getX());
			  pieceLocations.get(i).setY(50 + parent.getY());
		  }
	  }
	  System.out.println("WOWOWO");
  }
 
  public JPanel getChessBoard()
  {
	 return chessBoard;
  }
  
  public JLayeredPane getLayeredPane()
  {
	  return layeredPane;
  }
  
// Implement Inherited Abstract methods
  public void mouseClicked(MouseEvent e) {}
  public void mouseMoved(MouseEvent e) {}
  public void mouseEntered(MouseEvent e){}
  public void mouseExited(MouseEvent e) {}
  public void actionPerformed(ActionEvent e) {}
 
}