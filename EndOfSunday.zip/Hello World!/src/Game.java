import java.awt.Component;
import java.awt.Point;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import java.util.*;

public class Game
{
	// Data members of the game
	// Constructor
	private ChessGUI myframe; 
	Game() 
	{
		myframe = new ChessGUI();
	}
	
	// Generate moves for a given piece.
	public ArrayList<ChessPiece> genValidMoves(ChessPiece p)
	{
		// given a piece to work with.
		return null;
	}
	
	// This function handles all of the user moves that can be done, generating a list of valid
	// moves for the GUI to allow that the player move
	public void userMove()
	{
		
	}
	
	// This function handles all of the computer moves, it generates a list of valid moves for the
	// AI to use as input and handles moving the piece visually.
	public void computerMove()
	{
		
	}
	
	// Main function 
	public static void main(String[] args) 
	{
		// Creating a new Game
		Game myGame = new Game();
		// Instantiate module 
		myGame.myframe.pack();
		myGame.myframe.setResizable(true);
		myGame.myframe.setLocationRelativeTo( null );
		myGame.myframe.setVisible(true); // Display board
		  
		// Computer Turn - lock all computer pieces from player interaction.
		for (int i = 0; i < 8; i++)
		{
			for (int j = 0; j < 2; j++)
			{
				JLabel chessPiece = null;
				Component c1 = myGame.myframe.getChessBoard().findComponentAt(75 * i,  75 * j + 50);
				Point parentLocation1 = c1.getParent().getLocation(); 
				int xAdjust1 = parentLocation1.x;
				int yAdjust1 = parentLocation1.y;
				chessPiece = (JLabel)c1;
				// Set the location of the piece rending it immovable.
				chessPiece.setLocation(xAdjust1, 50 + yAdjust1);
				chessPiece.setSize(chessPiece.getWidth(), chessPiece.getHeight()); // Set size of chess piece
				myGame.myframe.getLayeredPane().add(chessPiece, JLayeredPane.DRAG_LAYER);
			}
		}
			 
			  
	    java.awt.EventQueue.invokeLater(new Runnable() {
	          public void run() {
	            // new myTimer();
	        }
	    });
	  }

}
