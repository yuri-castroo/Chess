import java.awt.Component;
import java.awt.Point;
import java.io.IOException;

import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import java.util.*;
public class Game
{
	// Data members of the game
	// Constructor
	private ChessGUI myframe; 
	Game() 
	{
		myframe = new ChessGUI();
	}
	
	private void generatePawnMoves(ChessPiece p)
	{
		ArrayList<ChessPiece> arrChessPieces = myframe.getPieceLoc();
		boolean flagInFront = false;		
		for (int i = 0; i < arrChessPieces.size(); i++)
		{
			// Checking if there is any piece in front
			if ((arrChessPieces.get(i).getX() == p.getX()) && (arrChessPieces.get(i).getY() == (p.getY() - 75)))
			{
				flagInFront = true;
			}
			// Checking if any enemy pieces are diagonal to the piece.
			int diff = -75;
			for (int j = 0; j < 2; j++)
			{
				if(j == 1) diff = 75;
				if ((arrChessPieces.get(i).getX() == (p.getX() + diff)) && (arrChessPieces.get(i).getY() == (p.getY() - 75)))
				{
					if (!arrChessPieces.get(i).isType() == p.isType())
					{
						// Checking if the type is valid for a user or a computer.
						ChessPiece p2 = new ChessPiece(p.getX() + diff, p.getY() - 75, p.getName(), p.isType());
						if (p2.isType())
						{
							myframe.addValidLocU(p2);
						}
						else
						{
							myframe.addValidLocC(p2);
						}
					}
				}
			}
		}
		if (!flagInFront)
		{
			ChessPiece p2 = new ChessPiece(p.getX(), p.getY() - 75, p.getName(), p.isType());
			if (p2.isType())
			{
				myframe.addValidLocU(p2);
			}
			else
			{
				myframe.addValidLocC(p2);
			}
		}
		System.out.println("apsdaksd");
	}
	
	private void generateRookMoves(ChessPiece p)
	{
		
	}
	
	private void generateKnightMoves(ChessPiece p)
	{
		
	}
	
	private void generateBishopMoves(ChessPiece p)
	{
		
	}
	
	private void generateQueenMoves(ChessPiece p)
	{
		
	}
	
	private void generateKingMoves(ChessPiece p)
	{
		
	}
	
	// Generate moves for a given piece.
	private ArrayList<ChessPiece> genValidMoves(ChessPiece p)
	{
		// given a piece to work with.
		
		if ((p.getName() == "user_pawn") || (p.getName() == "comp_pawn")) generatePawnMoves(p);
		if (p.getName() == "rook") generateRookMoves(p);
		if (p.getName() == "knight") generateKnightMoves(p);
		if (p.getName() == "bishop") generateBishopMoves(p);
		if (p.getName() == "queen") generateQueenMoves(p);
		if (p.getName() == "king") generateKingMoves(p);
		
		return null;
	}
	
	// This function handles all of the user moves that can be done, generating a list of valid
	// moves for the GUI to allow that the player move
	public void userMove()
	{
		ArrayList<ChessPiece> arrChessPiece = myframe.getPieceLoc();
		for (int i = 0; i < arrChessPiece.size(); i++)
		{
			this.genValidMoves(arrChessPiece.get(i));
		}
		// Wait for piece locations to change.
	}
	
	// This function handles all of the computer moves, it generates a list of valid moves for the
	// AI to use as input and handles moving the piece visually.
	public void computerMove()
	{
		
	}
	
	// Main function 
	public static void main(String[] args) 
	{
		// Figure out whose turn it is - Computer or User
		System.out.println("Would you like to play white or black? (Enter 0 for white or 1 for black)");
		int decision = -1;
		try
		{
			decision = System.in.read();
		} catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// Creating a new Game
		Game myGame = new Game();
		myGame.userMove();
		// Instantiate module 
		myGame.myframe.pack();
		myGame.myframe.setResizable(true);
		myGame.myframe.setLocationRelativeTo( null );
		myGame.myframe.setVisible(true); // Display board
		  
		// Computer Turn - lock all computer pieces from player interaction.
		for (int i = 0; i < 8; i++)
		{
			for (int j = 0; j < 2; j++)
			{
				JLabel chessPiece = null;
				Component c1 = myGame.myframe.getChessBoard().findComponentAt(75 * i,  75 * j + 50);
				Point parentLocation1 = c1.getParent().getLocation(); 
				int xAdjust1 = parentLocation1.x;
				int yAdjust1 = parentLocation1.y;
				chessPiece = (JLabel)c1;
				// Set the location of the piece rending it immovable.
				chessPiece.setLocation(xAdjust1, 50 + yAdjust1);
				chessPiece.setSize(chessPiece.getWidth(), chessPiece.getHeight()); // Set size of chess piece
				myGame.myframe.getLayeredPane().add(chessPiece, JLayeredPane.DRAG_LAYER);
			}
		}
			 
			  
	    java.awt.EventQueue.invokeLater(new Runnable() {
	          public void run() {
	            // new myTimer();
	        }
	    });
	  }

}
