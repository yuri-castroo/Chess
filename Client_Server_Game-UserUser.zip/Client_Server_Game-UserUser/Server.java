import java.net.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Server {

    ServerSocket myServerSocket;
    static ArrayList<Client> clientArrayList = new ArrayList<>();
    Game serverGame;
    	
    public void receiveClients() throws IOException
    {
        while(true){ // Create socket
        	Socket mySocket = myServerSocket.accept();
            Client client = new Client(mySocket); // Create Client from socket
            client.name = String.valueOf(clientArrayList.size()+1); // Set client name
            clientArrayList.add(client); // Add client to list
            ClientHandler thread = new ClientHandler(client); // Create new thread
            thread.start(); // Start thread
        }
    }

    // Implement case logic here!!!
    void gameEngine(Client myClient, String message)
    {
        switch(message)
        {
            case "READY": System.out.println("Received READY!!!"); break;
            case "OK": System.out.println("Received OK!!!"); break;
            case "ILLEGAL": System.out.println("Received OK!!!"); break;
            default:
            // Have the translated message go into the User message.
            	if (myClient.name.compareTo("1") == 0)
            	{
            		serverGame.userMove(null, message, false);
            	}
            	else
            	{
            		serverGame.userMove(null, message, true);
            	}
        }
    }

    public static void main(String[] args) {
        int port = 4000;
        try {
            System.out.println("Please connect both clients to the following IP Address and Port Number: ");
            System.out.println("Server ip: " + InetAddress.getLocalHost().getHostAddress());
            System.out.println("Server port: " + port);
            Server myServer = new Server(); // Set up new server
           myServer.serverGame = new Game(null, 0);
            myServer.myServerSocket = new ServerSocket(port); // Connect the server socket
            myServer.receiveClients(); // Connect to clients

        } catch (IOException ex) {
            System.out.println("Exception caught when trying to listen on port " + port + " or listening for a connection");
            System.out.println(ex.getMessage());
        }
    }

    private class ClientHandler extends Thread{

        Client cliSok;

        //Constructor
        public ClientHandler(Client myClient) {
            super("ClientHandler");
            this.cliSok = myClient;
        }

        public void run() {
            try {
                String clientIn;
               cliSok.o.println("WELCOME");
                if(cliSok.name.equals("1")) cliSok.o.println("INFO 5000 WHITE");
                else if(cliSok.name.equals("2")) cliSok.o.println("INFO 5000 BLACK");
                cliSok.reader = new BufferedReader(new InputStreamReader(cliSok.client.getInputStream()));
                while((clientIn = cliSok.reader.readLine()) != null) { // Read in client input
                    System.out.println("Received message: " + clientIn); // OK/Ready

                    gameEngine(cliSok, clientIn);

                    for(Client c : clientArrayList){ // Can put for loop contents into a function
                        if(c == cliSok)continue;
                        c.o.println("[" + cliSok.name + "] " + clientIn);
                    }
                    if(clientIn.equals("QUIT")) break;
                }
                cliSok.client.close();
                System.exit(0); // Exit at the end
//                cliSok.client.close();
            } catch(IOException ex) {
                ex.printStackTrace();
            }
        }
    }
}

