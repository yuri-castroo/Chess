import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Client {
	    public Client(Socket client) throws IOException {
        this.client = client;
        o = new PrintWriter(client.getOutputStream(), true);
        scanner = new Scanner(System.in);
    }

//    String host = "localhost";
//    int port = 5555;
    public Socket client;
    public PrintWriter o;
    public Scanner scanner;
    public BufferedReader reader;
    public String userInput = "";
    public String name;
    public static void main(String[] args) throws IOException {

        String host = "localhost";
        int port = 4000;

        try {
            Socket client = new Socket(host, port);
            PrintWriter o = new PrintWriter(client.getOutputStream(), true);
            Scanner scanner = new Scanner(System.in);
            String userInput;
            Thread thread = new Thread(new ClientHandler(client));
            thread.start();

            //read user
            while ((userInput = scanner.nextLine()) != null) {
                o.println(userInput); // Send coordinates out to server
            }
            client.close();
        }

        catch (UnknownHostException e) {
            System.err.println("Don't know about host " + host);
            System.exit(1);
        } catch (IOException e) {
            System.err.println("Couldn't get I/O for the connection to " +
                    host);
            System.exit(1);
        }
    }
}

class ClientHandler implements  Runnable{
    BufferedReader in;
    public ClientHandler (Socket socket){
        try{
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        }
        catch(IOException e){
            e.printStackTrace();
        }

    }
    @Override
    public void run() { // Implement Runnable method
        String fromServer;
        try{
            while(true){
                fromServer = in.readLine(); // Read in server input
                if(fromServer != null){
                    System.out.println(fromServer); // Print out server input on client console
                    if(fromServer.equals("QUIT")){System.exit(0);} // Quit if needed
                }
            }
        }
        catch (IOException e){
            e.printStackTrace();
        }
    }
}
