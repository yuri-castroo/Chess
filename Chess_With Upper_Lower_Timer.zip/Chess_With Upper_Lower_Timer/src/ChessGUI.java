import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.Timer;
 
public class ChessGUI extends JFrame implements MouseListener, MouseMotionListener, ActionListener {

  // Define class variables
  private static final long serialVersionUID = 1L; // Used for what??? 
  JLayeredPane layeredPane;
  JPanel chessBoard;
  JLabel chessPiece;
  int xAdjust;
  int yAdjust;
  Container initParent; // Parent of initial chess piece to move 
  
  // Timer GUI-specific variables 
  private JLabel timeLabel = new JLabel();
  private myTimer panel = new myTimer();
  private myTimer panel2 = new myTimer();
  
  // Timer-specific variables
  private static final int ONE_SECOND = 1000;
  private int count = 0;
  private boolean isTimerActive = false;
  private Timer tmr = new Timer(ONE_SECOND, this);
 
  //Format time 
  private String formatTime(int count) {
      int hours = count / 3600;
      int minutes = (count-hours*3600)/60;
      int seconds = count-minutes*60;

      return String.format("%02d", hours) + " : " + String.format("%02d", minutes) + " : " + String.format("%02d", seconds);
  }
  
  // Constructor 
  public ChessGUI()
  {
	  Dimension boardSize = new Dimension(600, 700);
	 
	  // Use Layered Pane for Chess GUI  
	  layeredPane = new JLayeredPane();
	  getContentPane().add(layeredPane);
	  layeredPane.setPreferredSize(boardSize);
	  layeredPane.addMouseListener(this);
	  layeredPane.addMouseMotionListener(this);

	  count=0;
  	  timeLabel.setText(formatTime(count));
  	  timeLabel.setText("         ");

	  
	  // Timer GUI 
	  timeLabel = new JLabel();
	  timeLabel.setBorder(BorderFactory.createRaisedBevelBorder());
      layeredPane.add(panel.getPanel(), BorderLayout.SOUTH);
      panel.getPanel().setBounds(250, 25, 100, 100);
      layeredPane.add(panel2.getPanel(), BorderLayout.SOUTH);
      panel2.getPanel().setBounds(250, 650, 100, 100);
      //panel.setLayout(new BorderLayout());
      //panel.setBounds(0, 0, 5, 5);
      
      // Begin timer 
      count = 0; 
      isTimerActive = true;
      tmr.start();
	 
	  //Add a chess board to the Layered Pane 
	  chessBoard = new JPanel();
	  layeredPane.add(chessBoard, JLayeredPane.DEFAULT_LAYER);
	  chessBoard.setLayout( new GridLayout(8, 8) );
	  chessBoard.setPreferredSize( boardSize );
	  chessBoard.setBounds(0, 50, 600, 600);
	 
	  // Create initial board 
	  for (int i = 0; i < 64; i++) 
	  {
		  JPanel square = new JPanel( new BorderLayout()); // Create board square
		  chessBoard.add( square ); // Add square to board 
		  int row = (i / 8) % 2; // Get row 
		  if (row == 0) square.setBackground( i % 2 == 0 ? Color.LIGHT_GRAY : Color.DARK_GRAY );
		  else square.setBackground( i % 2 == 0 ? Color.DARK_GRAY  : Color.LIGHT_GRAY );
	  }
	  
	  //Add a few pieces to the board 
	  ArrayList<JLabel> pieceList = new ArrayList<>();
	  String s = System.getProperty("user.dir") + "\\src\\"; // Main file path 
	  String s1 = s + "b"; // File path for all black strings
	  String s2 = s + "w"; // File path for all white strings
	  
	  // Put chess pieces in a list 
	  for(int i = 1; i <= 64; i++)
	  {
		  JLabel piece = new JLabel(); 
		  if(i <= 8) piece = new JLabel( new ImageIcon( s1 + i + ".png") ); // Valued black pieces
		  else if(i > 8 && i <= 16) piece = new JLabel( new ImageIcon( s1 + ".png") ); // Black pawns
		  else if(i >= 49 && i <= 56) piece = new JLabel( new ImageIcon( s2  + ".png") ); // White pawns
		  else if(i > 56 && i <= 64) piece = new JLabel( new ImageIcon( s2 + (65-i) + ".png") ); // Valued white pieces
		  pieceList.add(piece);
	  }
	  
	  // Create list of panels
	  ArrayList<JPanel> jpanelList = new ArrayList<>(); 
	  for(int i = 0; i < 64; i++)
	  {
		  JPanel myPanel = (JPanel)chessBoard.getComponent(i);
		  jpanelList.add(myPanel); 
	  }
	  
	  // Add chess piece to panels
	  for(int i = 0; i < pieceList.size(); i++)
	  {
		  jpanelList.get(i).add(pieceList.get(i));
	  }
  }
 
  // If user presses mouse
  public void mousePressed(MouseEvent e)
  {
	  chessPiece = null; // Initialize chess piece 
	  Component c =  chessBoard.findComponentAt(e.getX(), e.getY()); // Get piece coordinates
	  initParent = c.getParent(); // Set initial parent! (Put chess piece back here if invalid position specified) 
	  
	  if (c instanceof JPanel) return; // If user clicks on board (not chess piece) 
	 
	  // Determine coordinates of new point 
	  Point parentLocation = c.getParent().getLocation(); 
	  xAdjust = parentLocation.x - e.getX();
	  yAdjust = parentLocation.y - e.getY();
	  chessPiece = (JLabel)c;
	  
	  chessPiece.setLocation(e.getX() + xAdjust, e.getY() + yAdjust); // Set new location 
	  chessPiece.setSize(chessPiece.getWidth(), chessPiece.getHeight()); // Set size of chess piece
	  layeredPane.add(chessPiece, JLayeredPane.DRAG_LAYER); // Add piece to layered pane
  }
 
  // Move chess piece around board
  public void mouseDragged(MouseEvent me) 
  {
	  if (chessPiece == null) return; // If chess piece is not defined, return
	  chessPiece.setLocation(me.getX() + xAdjust, me.getY() + yAdjust); // Else set location
  }
 
  // Put chess piece back onto chess board
  public void mouseReleased(MouseEvent e) 
  {
	  if(chessPiece == null) return; // If chess piece is not defined, return
	  
	  chessPiece.setVisible(false); // Hide chess piece momentarily
	  Component c =  chessBoard.findComponentAt(e.getX(), e.getY()); // Find chess piece
	  
	  if (c instanceof JLabel) // If mouse clicks on pre-existing chess piece
	  { 
		  Container parent = c.getParent(); 
		  parent.remove(0); // Remove previous chess piece! - Might need to edit later!
		  parent.add( chessPiece ); // Add new piece 
	  }
	  else // If mouse clicks on board space (empty square)
	  {
		  Container parent = (Container) c;
		  if(e.getX() >= 0 && e.getX() <= 575 && e.getY() >= 0 && e.getY() <= 575) // Check bounds! 
		  {
			  parent.add( chessPiece );
		  }
		  else initParent.add(chessPiece); // Else put chess piece back in original spot 
	  }
	  chessPiece.setVisible(true); // Display chess piece 
  }
 
// Implement Inherited Abstract methods
  public void mouseClicked(MouseEvent e) {}
  public void mouseMoved(MouseEvent e) {}
  public void mouseEntered(MouseEvent e){}
  public void mouseExited(MouseEvent e) {}
  public void actionPerformed(ActionEvent e) 
  {
  	if (isTimerActive) 
  	{
        count++;
        timeLabel.setText(formatTime(count));
        System.out.println(count);
        if(count >= 5)
        {
        	tmr.restart(); // Counter until 10 sec
        	isTimerActive = false;
        	count = 0;
        	timeLabel.setText("Time up!");
        	return;
        }
    }
  }
 
  // Main function 
  public static void main(String[] args) 
  {
	  JFrame frame = new ChessGUI(); // Instantiate module 
	  frame.setDefaultCloseOperation(DISPOSE_ON_CLOSE );
	  frame.pack();
	  frame.setResizable(true);
	  frame.setLocationRelativeTo( null );
	  frame.setVisible(true); // Display board
	  
      java.awt.EventQueue.invokeLater(new Runnable() {
          public void run() {
            new myTimer();
          }
       });
  }
}